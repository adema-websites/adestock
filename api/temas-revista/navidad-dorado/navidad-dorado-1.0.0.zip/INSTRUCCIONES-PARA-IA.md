# Navidad dorado: guía para pedir variantes a una IA

Este tema usa el formato 1 de temas de revista de Adestock.
- Solo se permiten los campos de tema.json del contrato (colores #rrggbb, 5 fuentes cerradas).
- tema.css: sin url(), @import, @media, @keyframes, !important ni position: fixed; solo clases de la hoja.
- No cambies el id si querés una variante: creá otro id y una versión 1.0.0.
